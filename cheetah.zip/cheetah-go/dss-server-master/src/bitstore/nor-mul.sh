mv /root/DssServer/src/bitstore/bitstore.go /root/DssServer/src/bitstore/bitstore.goNOR
mv /root/DssServer/src/bitstore/bitstore.goMUL /root/DssServer/src/bitstore/bitstore.go
