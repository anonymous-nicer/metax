
mv /root/DssServer/src/bitstore/bitstore.go /root/DssServer/src/bitstore/bitstore.goMUL
mv /root/DssServer/src/bitstore/bitstore.goNOR /root/DssServer/src/bitstore/bitstore.go
