go build main1.go
