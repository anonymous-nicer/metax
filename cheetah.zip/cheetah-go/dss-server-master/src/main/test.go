package main
import "../bitstore"

func main (){
	bitstore.test()
}
