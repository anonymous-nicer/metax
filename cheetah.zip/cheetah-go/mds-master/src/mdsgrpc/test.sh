rm -rf /mnt/nvme11/*
./gsmds
