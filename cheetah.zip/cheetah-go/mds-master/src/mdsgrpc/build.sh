go build gsmds1.go
#go build gsmds2.go
#go build gsmds3.go
#go build gsmds.go
