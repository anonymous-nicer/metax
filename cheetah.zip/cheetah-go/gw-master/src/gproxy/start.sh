#gw start
rm -rf nohup.out
nohup ./gproxy startAllDescription -port=8080 &
