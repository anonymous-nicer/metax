#!/bin/bash

go build gproxy.go
